<h1>Description</h1>
Cartoon Fight is a 2D battle game to play against your friends
with your favorites cartoon characters. 
